import type {
  FinancialDataset,
  InvestigationCandidate,
} from "../../types/financial.js";

import {
  paymentEvidence,
  refundEvidence,
} from "../evidenceBuilder.js";

export function detectRefundAmountMismatch(
  dataset: FinancialDataset
): InvestigationCandidate[] {
  const candidates: InvestigationCandidate[] = [];

  for (const refund of dataset.refunds) {
    const payment = dataset.payments.find(
      (item) => item.paymentId === refund.paymentId
    );

    if (!payment) {
      continue;
    }

    /*
     * A refund should not exceed the original payment.
     */

    if (refund.amount <= payment.amount) {
      continue;
    }

    const leakage =
      refund.amount - payment.amount;

    candidates.push({
      caseId: `INV-REFUND-MISMATCH-${refund.refundId}`,
      type: "REFUND_AMOUNT_MISMATCH",
      orderId: refund.orderId,
      paymentId: refund.paymentId,
      refundIds: [refund.refundId],
      expectedAmount: payment.amount,
      actualAmount: refund.amount,
      potentialLeakage: leakage,
      evidence: [
        paymentEvidence(
          payment,
          "amount",
          `Original payment amount was ${payment.amount}.`
        ),
        refundEvidence(
          refund,
          "amount",
          `Refund amount was ${refund.amount}, exceeding the payment.`
        ),
      ],
      deterministicReason:
        `Refund ${refund.refundId} exceeds the original payment by ${leakage}.`,
    });
  }

  return candidates;
}