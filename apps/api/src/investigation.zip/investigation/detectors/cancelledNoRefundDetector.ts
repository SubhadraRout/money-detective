import type {
  FinancialDataset,
  InvestigationCandidate,
} from "../../types/financial.js";

import {
  orderEvidence,
  orderAmountEvidence,
  paymentEvidence,
} from "../evidenceBuilder.js";

export function detectCapturedCancelledNoRefund(
  dataset: FinancialDataset
): InvestigationCandidate[] {
  const candidates: InvestigationCandidate[] = [];

  const refundedByPayment = new Set(
    dataset.refunds.map(
      (refund) => refund.paymentId
    )
  );

  for (const order of dataset.orders) {
    if (order.status !== "cancelled") {
      continue;
    }

    const payment = dataset.payments.find(
      (item) =>
        item.orderId === order.orderId &&
        item.status === "captured"
    );

    if (!payment) {
      continue;
    }

    if (refundedByPayment.has(payment.paymentId)) {
      continue;
    }

    candidates.push({
      caseId: `INV-CANCELLED-NO-REFUND-${order.orderId}`,
      type: "CAPTURED_CANCELLED_NO_REFUND",
      orderId: order.orderId,
      paymentId: payment.paymentId,
      expectedAmount: 0,
      actualAmount: payment.amount,
      potentialLeakage: payment.amount,
      evidence: [
        orderEvidence(
          order,
          "Order is cancelled but payment was captured."
        ),
        orderAmountEvidence(
          order,
          `Cancelled order amount is ${order.orderAmount}.`
        ),
        paymentEvidence(
          payment,
          "status",
          "Payment status is captured."
        ),
        paymentEvidence(
          payment,
          "amount",
          `Captured payment amount is ${payment.amount}.`
        ),
      ],
      deterministicReason:
        `Order ${order.orderId} was cancelled after a payment of ${payment.amount} was captured, but no refund was found.`,
    });
  }

  return candidates;
}