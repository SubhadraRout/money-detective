import type {
  FinancialDataset,
  InvestigationCandidate,
} from "../../types/financial.js";

import {
  paymentEvidence,
  settlementEvidence,
  feeEvidence,
} from "../evidenceBuilder.js";

export function detectSettlementMismatch(
  dataset: FinancialDataset
): InvestigationCandidate[] {
  const candidates: InvestigationCandidate[] = [];

  for (const settlement of dataset.settlements) {
    const payment = dataset.payments.find(
      (item) =>
        item.paymentId === settlement.paymentId
    );

    if (!payment) {
      continue;
    }

    const fees = dataset.fees
      .filter(
        (fee) =>
          fee.paymentId === payment.paymentId
      )
      .reduce(
        (sum, fee) => sum + fee.amount,
        0
      );

    const taxes = dataset.fees
      .filter(
        (fee) =>
          fee.paymentId === payment.paymentId
      )
      .reduce(
        (sum, fee) => sum + fee.tax,
        0
      );

    const expectedNet =
      settlement.grossAmount -
      fees -
      taxes +
      settlement.adjustments;

    const difference =
      expectedNet - settlement.netAmount;

    /*
     * Small floating point differences should not
     * generate investigations.
     */

    if (Math.abs(difference) < 0.01) {
      continue;
    }

    candidates.push({
      caseId: `INV-SETTLEMENT-MISMATCH-${settlement.settlementId}`,
      type: "SETTLEMENT_MISMATCH",
      orderId: payment.orderId,
      paymentId: payment.paymentId,
      settlementId: settlement.settlementId,
      expectedAmount: expectedNet,
      actualAmount: settlement.netAmount,
      potentialLeakage: Math.abs(difference),
      evidence: [
        paymentEvidence(
          payment,
          "amount",
          `Payment amount was ${payment.amount}.`
        ),
        settlementEvidence(
          settlement,
          "grossAmount",
          `Settlement gross amount was ${settlement.grossAmount}.`
        ),
        settlementEvidence(
          settlement,
          "fees",
          `Settlement recorded fees of ${settlement.fees}.`
        ),
        settlementEvidence(
          settlement,
          "taxes",
          `Settlement recorded taxes of ${settlement.taxes}.`
        ),
        settlementEvidence(
          settlement,
          "adjustments",
          `Settlement recorded adjustments of ${settlement.adjustments}.`
        ),
        settlementEvidence(
          settlement,
          "netAmount",
          `Settlement net amount was ${settlement.netAmount}.`
        ),
        ...dataset.fees
          .filter(
            (fee) =>
              fee.paymentId ===
              payment.paymentId
          )
          .map((fee) =>
            feeEvidence(
              fee,
              "amount",
              `Recorded fee amount was ${fee.amount}.`
            )
          ),
      ],
      deterministicReason:
        `Expected settlement net amount was ${expectedNet}, but the actual settlement was ${settlement.netAmount}. Difference: ${Math.abs(difference)}.`,
    });
  }

  return candidates;
}